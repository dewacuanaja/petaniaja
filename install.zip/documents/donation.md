# 您可以通过虚拟向我捐赠

## Ethereum Mainnet/HECO/BSC
- USDT/ETH/BNB/HT
```
0xB08b731653515b083deE362fefFc45d5eb96c35d
```
<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/donation/main.png" width=300>
